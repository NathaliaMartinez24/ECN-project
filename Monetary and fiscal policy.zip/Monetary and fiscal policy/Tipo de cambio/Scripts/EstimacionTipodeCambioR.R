# Cargar librerias principales

# readxl, cargar archivos excel
# tsDyn, modelo de correccion de errores
# vars, modelo var
# zoo y lubridate, gestion de variables de tiempo
# tseries, pruebas de raíz unitaria

install.packages("readxl")
install.packages("tsDyn")
install.packages("stats")
install.packages("vars")
install.packages("zoo")
install.packages("lubridate")
install.packages("tseries")
install.packages("urca")
install.packages("ggplot2")
install.packages("stargazer")

library(ggplot2)
library(stargazer)

lapply(c("readxl","tsDyn","stats" ,"vars","zoo","lubridate","tseries","urca"), library, character.only = TRUE)

# Cargar base de datos
Base_Tipo_Cambio <- read_excel("Naty Uni/Pol[itica Monetaria y Fiscal/Proyecto/proyect pol/Tipo de cambio/Datos/Base_Tipo_Cambio.xlsx")

# Tipos de datos en la base de datos
data$Fecha<-as.Date(data$Fecha,format="%d/%m/%Y")

# Nuevas variables

# Logaritmos

# Inflacion y Balanza sin log

data$log_pib_real_ecuador <- log(data$PIB_Real_Ecuador)
data$log_pib_real_eurozona <- log(data$PIB_Real_Eurozona)
data$log_indice_precios_ecuador <- log(data$Indice_Precios_Ecuador)
data$log_indice_precios_eurozona <- log(data$Indice_Precios_Eurozona)
data$log_tipo_cambio_nominal <- log(data$Tipo_Cambio_Nominal)
data$log_tipo_cambio_real <- log(data$Tipo_Cambio_Real)
data$log_tasa_ecuador <- log(data$Tasa_Ecuador)
data$log_tasa_europa <- log(data$Tasa_Europa)

# Diferencias

data$diferencia_log_pib_real_ecuador <- c(NA, diff(data$log_pib_real_ecuador, 1))
data$diferencia_log_pib_real_eurozona <- c(NA, diff(data$log_pib_real_eurozona, 1))
data$diferencia_log_indice_precios_ecuador <- c(NA, diff(data$log_indice_precios_ecuador, 1))
data$diferencia_log_indice_precios_eurozona <- c(NA, diff(data$log_indice_precios_eurozona, 1))
data$diferencia_log_tipo_cambio_nominal <- c(NA, diff(data$log_tipo_cambio_nominal, 1))
data$diferencia_log_tipo_cambio_real <- c(NA, diff(data$log_tipo_cambio_real, 1))
data$diferencia_log_tasa_ecuador <- c(NA, diff(data$log_tasa_ecuador, 1))
data$diferencia_log_tasa_europa <- c(NA, diff(data$log_tasa_europa, 1))
data$diferencia_inflacion_ecuador <- c(NA, diff(data$Inflacion_Ecuador, 1))
data$diferencia_inflacion_eurozona <- c(NA, diff(data$Inflacion_Eurozona, 1))
data$diferencia_balanza_ecuador <- c(NA, diff(data$Balanza_Ecuador, 1))

# Lagged variables

data$lag_diferencia_log_pib_real_ecuador <- stats::lag(data$diferencia_log_pib_real_ecuador, -1)
data$lag_diferencia_log_pib_real_eurozona <- stats::lag(data$diferencia_log_pib_real_eurozona, -1)
data$lag_diferencia_log_indice_precios_ecuador <- stats::lag(data$diferencia_log_indice_precios_ecuador, -1)
data$lag_diferencia_log_indice_precios_eurozona <- stats::lag(data$diferencia_log_indice_precios_eurozona, -1)
data$lag_diferencia_log_tipo_cambio_nominal <- stats::lag(data$diferencia_log_tipo_cambio_nominal, -1)
data$lag_diferencia_log_tipo_cambio_real <- stats::lag(data$diferencia_log_tipo_cambio_real, -1)
data$lag_diferencia_log_tasa_ecuador <- stats::lag(data$diferencia_log_tasa_ecuador, -1)
data$lag_diferencia_log_tasa_europa <- stats::lag(data$diferencia_log_tasa_europa, -1)
data$lag_diferencia_inflacion_ecuador <- stats::lag(data$diferencia_inflacion_ecuador, -1)
data$lag_diferencia_inflacion_eurozona <- stats::lag(data$diferencia_inflacion_eurozona, -1)
data$lag_diferencia_balanza_ecuador <- stats::lag(data$diferencia_balanza_ecuador, -1)


# Graficar series de tiempo

# Serie de tiempo del PIB Real Ecuador

 ggplot(data, aes(x = Fecha, y = PIB_Real_Ecuador)) +
  geom_line() + 
  geom_point() + 
  labs(title = "Serie de Tiempo del PIB Real Ecuador",
       x = "Fecha",
       y = "PIB Real Ecuador")

# Serie de tiempo del PIB Real Eurozona

ggplot(data, aes(x = Fecha, y = PIB_Real_Eurozona)) +
  geom_line() + 
  geom_point() + 
  labs(title = "Serie de Tiempo del PIB Real Eurozona",
       x = "Fecha",
       y = "PIB Real Eurozona")

# Serie de tiempo del Indice_Precios_Eurozona

ggplot(data, aes(x = Fecha, y = Indice_Precios_Eurozona)) +
  geom_line() + 
  geom_point() + 
  labs(title = "Serie de Tiempo del Indice Precios Eurozona",
       x = "Fecha",
       y = "Indice Precios Eurozona")


# Serie de tiempo del Indice_Precios_Ecuador

ggplot(data, aes(x = Fecha, y = Indice_Precios_Ecuador)) +
  geom_line() + 
  geom_point() + 
  labs(title = "Serie de Tiempo del Indice Precios Ecuador",
       x = "Fecha",
       y = "Indice Precios Eurozona")

# Plot for "Tipo Cambio Nominal"
ggplot(data, aes(x = Fecha, y = Tipo_Cambio_Nominal)) +
  geom_line() + 
  geom_point() + 
  labs(title = "Serie de Tiempo del Tipo Cambio Nominal",
       x = "Fecha",
       y = "Tipo Cambio Nominal")

# Plot for "Tipo Cambio Real"
ggplot(data, aes(x = Fecha, y = Tipo_Cambio_Real)) +
  geom_line() + 
  geom_point() + 
  labs(title = "Serie de Tiempo del Tipo Cambio Real",
       x = "Fecha",
       y = "Tipo Cambio Real")

# Plot for "Inflacion Ecuador"
 ggplot(data, aes(x = Fecha, y = Inflacion_Ecuador)) +
  geom_line() + 
  geom_point() + 
  labs(title = "Serie de Tiempo del Inflacion Ecuador",
       x = "Fecha",
       y = "Inflacion Ecuador")

# Plot for "Inflacion Eurozona"
 ggplot(data, aes(x = Fecha, y = Inflacion_Eurozona)) +
  geom_line() + 
  geom_point() + 
  labs(title = "Serie de Tiempo del Inflacion Eurozona",
       x = "Fecha",
       y = "Inflacion Eurozona")

# Plot for "Tasa Ecuador"
 ggplot(data, aes(x = Fecha, y = Tasa_Ecuador)) +
  geom_line() + 
  geom_point() + 
  labs(title = "Serie de Tiempo del Tasa Ecuador",
       x = "Fecha",
       y = "Tasa Ecuador")

# Plot for "Tasa Europa"
 ggplot(data, aes(x = Fecha, y = Tasa_Europa)) +
  geom_line() + 
  geom_point() + 
  labs(title = "Serie de Tiempo del Tasa Europa",
       x = "Fecha",
       y = "Tasa Europa")


# Balanza Ecuador

  ggplot(data, aes(x = Fecha, y = Balanza_Ecuador)) +
  geom_line() + 
  geom_point() + 
  labs(title = "Serie de Tiempo del Balanza Ecuador",
       x = "Fecha",
       y = "Balanza Ecuador")



# Realizar test respectivos

# Borrar los datos que sean NA
data <- na.omit(data)

# Test de raiz unitaria

# Variables

# Normal

df_log_pib_real_ecuador <- adf.test(data$log_pib_real_ecuador, alternative = "stationary")
df_log_pib_real_eurozona <- adf.test(data$log_pib_real_eurozona, alternative = "stationary")
df_log_indice_precios_ecuador <- adf.test(data$log_indice_precios_ecuador, alternative = "stationary")
df_log_indice_precios_eurozona <- adf.test(data$log_indice_precios_eurozona, alternative = "stationary")
df_log_tipo_cambio_nominal <- adf.test(data$log_tipo_cambio_nominal, alternative = "stationary")
df_log_tipo_cambio_real <- adf.test(data$log_tipo_cambio_real, alternative = "stationary")
df_log_tasa_ecuador <- adf.test(data$log_tasa_ecuador, alternative = "stationary")
df_log_tasa_europa <- adf.test(data$log_tasa_europa, alternative = "stationary")

# Diferencias

df_diferencia_log_pib_real_ecuador <- adf.test(data$diferencia_log_pib_real_ecuador, alternative = "stationary")
df_diferencia_log_pib_real_eurozona <- adf.test(data$diferencia_log_pib_real_eurozona, alternative = "stationary")
df_diferencia_log_indice_precios_ecuador <- adf.test(data$diferencia_log_indice_precios_ecuador, alternative = "stationary")
df_diferencia_log_indice_precios_eurozona <- adf.test(data$diferencia_log_indice_precios_eurozona, alternative = "stationary")
df_diferencia_log_tipo_cambio_nominal <- adf.test(data$diferencia_log_tipo_cambio_nominal, alternative = "stationary")
df_diferencia_log_tipo_cambio_real <- adf.test(data$diferencia_log_tipo_cambio_real, alternative = "stationary")
df_diferencia_log_tasa_ecuador <- adf.test(data$diferencia_log_tasa_ecuador, alternative = "stationary")
df_diferencia_log_tasa_europa <- adf.test(data$diferencia_log_tasa_europa, alternative = "stationary")
df_diferencia_inflacion_ecuador <- adf.test(data$diferencia_inflacion_ecuador, alternative = "stationary")
df_diferencia_inflacion_eurozona <- adf.test(data$diferencia_inflacion_eurozona, alternative = "stationary")
df_diferencia_balanza_ecuador <- adf.test(data$diferencia_balanza_ecuador, alternative = "stationary")

# Resultados

# Variables

resultados <- data.frame(
  Variable = c('log_pib_real_ecuador', 'log_pib_real_eurozona', 'log_indice_precios_ecuador', 'log_indice_precios_eurozona', 'log_tipo_cambio_nominal', 'log_tipo_cambio_real', 'log_tasa_ecuador', 'log_tasa_europa'),
  Estadistico = c(df_log_pib_real_ecuador$statistic, df_log_pib_real_eurozona$statistic, df_log_indice_precios_ecuador$statistic, df_log_indice_precios_eurozona$statistic, df_log_tipo_cambio_nominal$statistic, df_log_tipo_cambio_real$statistic, df_log_tasa_ecuador$statistic, df_log_tasa_europa$statistic),
  P_valor = c(df_log_pib_real_ecuador$p.value, df_log_pib_real_eurozona$p.value, df_log_indice_precios_ecuador$p.value, df_log_indice_precios_eurozona$p.value, df_log_tipo_cambio_nominal$p.value, df_log_tipo_cambio_real$p.value, df_log_tasa_ecuador$p.value, df_log_tasa_europa$p.value)
)

# Diferencias

resultados_diferencias <- data.frame(
  Variable = c('diferencia_log_pib_real_ecuador', 'diferencia_log_pib_real_eurozona', 'diferencia_log_indice_precios_ecuador', 'diferencia_log_indice_precios_eurozona', 'diferencia_log_tipo_cambio_nominal', 'diferencia_log_tipo_cambio_real', 'diferencia_log_tasa_ecuador', 'diferencia_log_tasa_europa', 'diferencia_inflacion_ecuador', 'diferencia_inflacion_eurozona', 'diferencia_balanza_ecuador')
  ,
  Estadistico = c(df_diferencia_log_pib_real_ecuador$statistic, df_diferencia_log_pib_real_eurozona$statistic, df_diferencia_log_indice_precios_ecuador$statistic, df_diferencia_log_indice_precios_eurozona$statistic, df_diferencia_log_tipo_cambio_nominal$statistic, df_diferencia_log_tipo_cambio_real$statistic, df_diferencia_log_tasa_ecuador$statistic, df_diferencia_log_tasa_europa$statistic, df_diferencia_inflacion_ecuador$statistic, df_diferencia_inflacion_eurozona$statistic, df_diferencia_balanza_ecuador$statistic)
  ,
  P_valor = c(df_diferencia_log_pib_real_ecuador$p.value, df_diferencia_log_pib_real_eurozona$p.value, df_diferencia_log_indice_precios_ecuador$p.value, df_diferencia_log_indice_precios_eurozona$p.value, df_diferencia_log_tipo_cambio_nominal$p.value, df_diferencia_log_tipo_cambio_real$p.value, df_diferencia_log_tasa_ecuador$p.value, df_diferencia_log_tasa_europa$p.value, df_diferencia_inflacion_ecuador$p.value, df_diferencia_inflacion_eurozona$p.value, df_diferencia_balanza_ecuador$p.value)
  
)

# Ejecutar modelos

# Modelo 1 regresion con tendencia

# Independent variables
independent_vars = c('diferencia_log_pib_real_ecuador', 'diferencia_log_pib_real_eurozona', 'diferencia_log_indice_precios_ecuador', 'diferencia_log_indice_precios_eurozona', 'diferencia_log_tipo_cambio_nominal', 'diferencia_log_tipo_cambio_real', 'diferencia_log_tasa_ecuador', 'diferencia_log_tasa_europa', 'diferencia_inflacion_ecuador', 'diferencia_inflacion_eurozona', 'diferencia_balanza_ecuador')

# Constructing the formula

independent_vars = c('diferencia_log_pib_real_ecuador', 'diferencia_log_pib_real_eurozona', 'diferencia_log_indice_precios_ecuador', 'diferencia_log_indice_precios_eurozona', 'diferencia_log_tipo_cambio_nominal', 'diferencia_log_tasa_ecuador', 'diferencia_log_tasa_europa', 'diferencia_inflacion_ecuador', 'diferencia_inflacion_eurozona', 'diferencia_balanza_ecuador')
formula_parts = paste(independent_vars, collapse = " + ")
full_formula = paste("diferencia_log_tipo_cambio_real ~", formula_parts)

# Linear model
modelo1 <- lm(full_formula, data = data)

summary(modelo1)

stargazer(modelo1, type = "text")

# Tablas

stargazer(modelo1, type = "text")

# Modelo 2 var

data_var <- data[, c(independent_vars = c('diferencia_log_pib_real_ecuador', 'diferencia_log_pib_real_eurozona', 'diferencia_log_indice_precios_ecuador', 'diferencia_log_indice_precios_eurozona',  'diferencia_log_tipo_cambio_real', 'diferencia_log_tasa_ecuador', 'diferencia_log_tasa_europa', 'diferencia_inflacion_ecuador', 'diferencia_inflacion_eurozona', 'diferencia_balanza_ecuador')
)]

modelo_2_var <- VAR(data_var, p = 4)

summary(modelo_2_var$varresult$diferencia_log_tipo_cambio_real)

# Tablas

stargazer(modelo1, type = "text")

