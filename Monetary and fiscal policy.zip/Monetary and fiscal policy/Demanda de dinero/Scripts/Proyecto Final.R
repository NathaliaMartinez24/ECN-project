# Cargar librerias principales

# readxl, cargar archivos excel
# tsDyn, modelo de correccion de errores
# vars, modelo var
# zoo y lubridate, gestion de variables de tiempo
# tseries, pruebas de raíz unitaria

install.packages("readxl")
install.packages("tsDyn")
install.packages("stats")
install.packages("vars")
install.packages("zoo")
install.packages("lubridate")
install.packages("tseries")
install.packages("urca")
install.packages("ggplot2")
install.packages("stargazer")

lapply(c("readxl","tsDyn","stats" ,"vars","zoo","lubridate","tseries","urca", "ggplot2", "stargazer"), library, character.only = TRUE)

# Cargar base de datos
data<-read_excel("Naty Uni/Pol[itica Monetaria y Fiscal/Proyecto/proyect pol/Data/Proyecto_Demanda_Dinero.xlsx")

# Tipos de datos en la base de datos
data$Fecha<-as.Date(data$Fecha,format="%d/%m/%Y")

# Nuevas variables
# Logaritmos y diferencias
data$log_pib<-log(data$PIB_Corriente)
data$log_precios<-log(data$Indice_Precios)
data$log_m2<-log(data$M2)
data$log_interes<-log(data$Tasa_Interes)
data$inflacion<-c(NA, diff(data$log_precios, 1))
data$resta<-data$log_m2-data$log_precios-data$log_pib
data$diferecia_log_m2<-c(NA, diff(data$log_m2, 1))
data$diferecia_log_pib<-c(NA, diff(data$log_pib, 1))
data$diferecia_log_interes<-c(NA, diff(data$log_interes, 1))
data$lag_inflacion<- stats::lag(data$inflacion,-1)
data$lag_resta<- stats::lag(data$resta,-1)
data$lag_log_precios<-stats::lag(data$log_precios,-1)
data$lag_log_pib<-stats::lag(data$log_pib,-1)
data$lag_log_interes<-stats::lag(data$log_interes,-1)
data$tendencia <- 1:nrow(data)

# Graficar series de tiempo

# Serie de tiempo del PIB

ggplot(data, aes(x = Fecha, y = PIB_Corriente)) +
  geom_line() + 
  geom_point() + 
  labs(title = "Serie de Tiempo del PIB Corriente",
       x = "Fecha",
       y = "PIB Corriente") 

# Serie de tiempo del IPC

ggplot(data, aes(x = Fecha, y = Indice_Precios)) +
  geom_line() + 
  geom_point() + 
  labs(title = "Serie de Tiempo de IPC",
       x = "Fecha",
       y = "IPC") 

# Serie de tiempo del M2

ggplot(data, aes(x = Fecha, y = M2)) +
  geom_line() + 
  geom_point() + 
  labs(title = "Serie de Tiempo de M2 Líquidez Total",
       x = "Fecha",
       y = "M2") 

# Serie de tiempo de log de precios

ggplot(data, aes(x = Fecha, y = log_precios)) +
  geom_line() + 
  geom_point() + 
  labs(title = "Serie de Tiempo de Logaritmo Precios",
       x = "Fecha",
       y = "Log Precios") 

# Serie de tiempo de log de pib

ggplot(data, aes(x = Fecha, y = log_pib)) +
  geom_line() + 
  geom_point() + 
  labs(title = "Serie de Tiempo de M2 Logaritmo PIB Corriente",
       x = "Fecha",
       y = "Log PIB Corriente") 

# Serie de tiempo de log de m2

ggplot(data, aes(x = Fecha, y = log_m2)) +
  geom_line() + 
  geom_point() + 
  labs(title = "Serie de Tiempo de M2 Logaritmo M2",
       x = "Fecha",
       y = "Log M2") 

# Serie de tiempo de inflacion

ggplot(data, aes(x = Fecha, y = inflacion)) +
  geom_line() + 
  geom_point() + 
  labs(title = "Serie de Tiempo de Inflacion",
       x = "Fecha",
       y = "Inflacion") 

# Serie de tiempo de tasa de interes

ggplot(data, aes(x = Fecha, y = Tasa_Interes*100)) +
  geom_line() + 
  geom_point() + 
  labs(title = "Serie de Tiempo de Tasa de Interes",
       x = "Fecha",
       y = "Tasa de Interes") 

# Serie de tiempo de tasa de interes

ggplot(data, aes(x = Fecha, y = log_interes)) +
  geom_line() + 
  geom_point() + 
  labs(title = "Serie de Tiempo de Logaritmo Tasa de Interes",
       x = "Fecha",
       y = "Tasa de Interes") 


# Realizar test respectivos

# Borrar los datos que sean NA
data <- na.omit(data)

# Test de raiz unitaria

# Variables

df_log_pib <- adf.test(data$log_pib, alternative = "stationary")
df_log_precios <- adf.test(data$log_precios, alternative = "stationary")
df_log_m2 <- adf.test(data$log_m2, alternative = "stationary")
df_log_interes <- adf.test(data$log_interes, alternative = "stationary")


# Diferencias

df_diferecia_log_pib <- adf.test(data$diferecia_log_pib, alternative = "stationary")
inflacion <- adf.test(data$inflacion, alternative = "stationary")
df_diferecia_log_m2 <- adf.test(data$diferecia_log_m2, alternative = "stationary")
df_diferecia_log_interes <- adf.test(data$diferecia_log_interes, alternative = "stationary")

# Resultados

# Variables

resultados <- data.frame(
  Variable = c("log_pib", "log_precios", "log_m2", "log_interes"),
  Estadistico = c(df_log_pib$statistic, df_log_precios$statistic, df_log_m2$statistic, df_log_interes$statistic),
  P_valor = c(df_log_pib$p.value, df_log_precios$p.value, df_log_m2$p.value, df_log_interes$p.value)
)

# Diferencias

resultados_diferencias <- data.frame(
  Variable = c("diferecia_log_pib", "inflacion", "diferecia_log_m2", "diferecia_log_interes"),
  Estadistico = c(df_diferecia_log_pib$statistic, inflacion$statistic, df_diferecia_log_m2$statistic, df_diferecia_log_interes$statistic),
  P_valor = c(df_diferecia_log_pib$p.value, inflacion$p.value, df_diferecia_log_m2$p.value, df_diferecia_log_interes$p.value)
)

# Ejecutar modelos

# Modelo 1 regresion con tendencia

modelo1 <- lm(diferecia_log_m2 ~ inflacion + diferecia_log_pib + diferecia_log_interes + 
                lag_resta + lag_log_interes + lag_log_precios + lag_log_pib + tendencia, data = data)

robust_summary <- coeftest(modelo1, vcov. = vcovHC(modelo1, type = "HC3"))


# Modelo 2 var

data_var <- data[, c("diferecia_log_m2", "inflacion", "diferecia_log_pib", 
                     "diferecia_log_interes")]

modelo_2_var <- VAR(data_var, p = 3)

summary(modelo_2_var$varresult$diferecia_log_m2)

# Modelo 3 error correction model con cointegracion

data_vecm <- data[, c("diferecia_log_m2", "inflacion", "diferecia_log_pib", 
                      "diferecia_log_interes")]

# Probar cointegracion

johansen_test <- ca.jo(data_vecm, type = "trace", ecdet = "const", K = 2)
summary(johansen_test)

modelo_3_vecm <- VECM(data_vecm, lag = 3, r = 3)   

summary(modelo_3_vecm) 

# Tablas

stargazer(modelo1, type = "text")
